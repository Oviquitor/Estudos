import 'package:flutter/material.dart';
import 'screens/calculator.dart';

void main() => runApp(const Calculator());
