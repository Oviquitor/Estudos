class ExplosaoException implements Exception {}
