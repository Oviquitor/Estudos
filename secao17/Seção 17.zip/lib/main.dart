import 'package:flutter/material.dart';
import 'screens/campo_minado_app.dart';

void main() => runApp(const CampoMinadoApp());
